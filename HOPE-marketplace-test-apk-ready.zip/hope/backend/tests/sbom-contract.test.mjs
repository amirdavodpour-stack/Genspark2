import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const sbom = JSON.parse(fs.readFileSync(new URL('../sbom.json', import.meta.url), 'utf8'));

const stripRange = (v) => v.replace(/^[\^~]/, '');
const expected = (deps) => Object.entries(deps || {})
  .map(([name, version]) => `${name}@${stripRange(version)}`)
  .sort();

test('sbom.json component list matches package.json dependencies exactly', () => {
  const wantDeps = expected(pkg.dependencies);
  const wantDev = expected(pkg.devDependencies);
  const have = sbom.components.map((c) => `${c.name}@${c.version}`).sort();
  const haveRequired = sbom.components.filter((c) => c.scope === 'required').map((c) => `${c.name}@${c.version}`).sort();
  const haveOptional = sbom.components.filter((c) => c.scope === 'optional').map((c) => `${c.name}@${c.version}`).sort();

  assert.deepEqual(haveRequired, wantDeps, 'sbom.json is out of date with package.json "dependencies" -- run `npm run sbom`');
  assert.deepEqual(haveOptional, wantDev, 'sbom.json is out of date with package.json "devDependencies" -- run `npm run sbom`');
  assert.equal(have.length, wantDeps.length + wantDev.length, 'sbom.json has extra or duplicate components');
});

test('sbom.json declares a bomFormat and application component', () => {
  assert.equal(sbom.bomFormat, 'CycloneDX');
  assert.equal(sbom.metadata.component.name, pkg.name);
  assert.equal(sbom.metadata.component.version, pkg.version);
});
